<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/html" id="tmpl-fusion_table-shortcode">
	<div data-param="element_content">
		{{{ FusionPageBuilderApp.renderContent( element_content, cid, false ) }}}
	</div>
</script>
