<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.2
 */

?>
<script type="text/html" id="tmpl-fusion_tb_woo_notices-shortcode">
	{{{styles}}}
	<section {{{ _.fusionGetAttributes( wrapperAttr ) }}}>
		<div class="woocommerce-notices-wrapper">
			{{{output}}}
		</div>
	</section>
</script>
