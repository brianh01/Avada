<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/template" id="fusion-builder-front-end-preferences">
	<ul class="fusion-builder-module-settings fusion_builder_module_settings">
		<?php fusion_builder_preferences_loop( 'FusionApp.preferences' ); ?>
	</ul>
</script>
