<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.3
 */

?>
<script type="text/html" id="tmpl-fusion_tb_woo_checkout_tabs-shortcode">
	{{{styles}}}
	<div {{{ _.fusionGetAttributes( wrapperAttr ) }}}>
		{{{output}}}
	</div>
</script>
