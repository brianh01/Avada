<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.5
 */

?>
<script type="text/html" id="tmpl-fusion_twitter_timeline-shortcode">
		{{{ styles }}}
		<div {{{ _.fusionGetAttributes( atts ) }}}>
			<a {{{ _.fusionGetAttributes( iframeAtts ) }}}></a>
		</div>
</script>
